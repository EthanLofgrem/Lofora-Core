# Lofora-Core
This is the core of LOForA — the auto-forge project for generating and deploying HTML/CSS/JS to GitHub.
https://github.com/EthanLofgrem/Lofora-Core
